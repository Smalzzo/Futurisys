# Référence (routes)

Cette section peut être générée automatiquement via mkdocstrings si vous documentez les fonctions et modèles.

## app.api.predict

::: app.api.predict
    options:
      members:
        - predict
        - predict_by_id
        - health

