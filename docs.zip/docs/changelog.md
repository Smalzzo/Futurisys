# Journal des changements

- 0.1.0
  - Première version du service et de l’API
  - CI: build + tests + couverture
  - Docker: image FastAPI (port 7860) pour Spaces
